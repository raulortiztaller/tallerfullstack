function calcularHipotenusa(a,b){
    let h;
    h= Math.sqrt(Math.pow(a,2)+Math.pow(b,2))
    return h;
}
calcularHipotenusa(5,2);

function factorial(n){
    var total = 1; 
    for (i=1; i<=n; i++) {
        total = total * i; 
    }
    return total; 
}
factorial(6)

function factorialRecursivo(n){
    if(n==1){
        return n;
    }else{
        return n * factorialRecursivo(n-1);
    }
}
factorialRecursivo(5)