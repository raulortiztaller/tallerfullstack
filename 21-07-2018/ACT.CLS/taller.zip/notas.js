function sacarPromedio(estudiante, notas) {
    var nota = null;
    var promedio = null;
    var controlNotas = null;

        for (i = 0; i < notas.length; i++) {
        nota = notas[i];
        controlNotas = i + 1;
        if (nota != 0) {
            promedio += nota;

        }
        else {
            break;
        }

       /*for (i in notas) {
            nota = notas[i];
            controlNotas = i + 1;
            if (nota != 0) {
                promedio += nota;
    
            }
            else {
                break;
            }*/

    }
    promedio = (promedio / controlNotas);
    alert("El promedio de notas de " + estudiante + " es " + promedio + " que corresponde a " + controlNotas +" nota(s).");
}

function ingresarNotas() {

    var estudiante = prompt("Ingrese el nombre del estudiante :");
    var notas = prompt("Ingrese las notas del estudiantes, separadas por comas :").split(",")  ;
    notas = notas.map(Number);  
    sacarPromedio(estudiante,notas);
}

ingresarNotas();

