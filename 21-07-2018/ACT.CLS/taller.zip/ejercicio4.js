<script>
    ingresarNumeros();
    function ingresarNumeros() {
    
		var edadTotal = 0;
        var tamañoArray = 2;           
        var json = '{"datos":[';  

        for (i = 0 ;i < tamañoArray; i++) {
        
           	var nombre = prompt("Ingrese nombre");
            var apellido= prompt("Ingrese apellido");
            var edad= prompt("Ingrese edad");  
            var edadNum = parseFloat(edad);      
            edadTotal = edadTotal + edadNum;            

        }
        var objInt = "{"+'"Edad Total"' +":" + edadTotal + "}"; 
    	json += objInt;
        json +="]}";
        console.log(json);
        alert(json);
    }
</script>