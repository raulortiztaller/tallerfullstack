
var numeros = [10, 20, 30,40,50];
var total =0;

function suma(param) {    
    total += param;
    return total;
}

var suma = numeros.map(suma);
console.log(total);
