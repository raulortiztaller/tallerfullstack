    ingresarNumeros();

    function ingresarNumeros() {


        var tamañoArray = 7;           
        var json = '{"datos":[';  

        for (i = 0 ;i < tamañoArray; i++) {
        
            var textoVariable = "obj";
        
            var numero = prompt("Ingrese el numero " + (i+1) + ":");
            textoVariable = textoVariable.concat(i+1); 

            var objInt = "{"+'"'+ textoVariable + '"' +":" + numero + "}";
            json += objInt;
            if(i < (tamañoArray-1) )
                json += ",";       

        }

        json +="]}";
        console.log(json);
        alert(json);



    }